/*
 * Source: My Personal Script
 * Information
 * Modified By: Muh*** Irf** M*r** (Fannn.)
 * Contact Modified: 0853 3660 3330 (WhatsApp)
 * DICK CUTTING BEWARE
 */

/*
true = enable,
false = disable.

understand?
*/

module.exports = {
	session_folder_name: 'session',
	pairing_code: true,
	browser: ['Mac OS', 'chrome', '121.0.6167.159'],
	prefix: '.',
	pro: '*_Sedang melakukan pemrosesan data, tunggu sebentar..._*',
	caption: '*Ini hasilnya kak ✅*',
	image_url: 'https://i.ibb.co.com/QrMnTvy/MACHOBOT.jpg',
	audio_url: 'https://cdn.danitechno.com/audio/dj-joanna-breakbeat.mp3',
	linkgc: 'https://s.id/MachoBOT',
	gw_url: 'https://wa.me/qr/JX2BYBSOQ3YEN1',
	server_url: 'https://telegra.ph/file/5e01d6b0981855d2b835e.jpg',
	mode: 'group', // Private, Group, Both/All
	public_mode: true,
	offline_status: false,
	auto_update_profile_status: true,
	auto_read_messages: true,
	auto_typing: false,
	auto_recording: true,
	mongodb_uri: 'mongodb+srv://irfanchasper112:9FcqUVUVSKRA1P8b@datauserwabot.pug3qvn.mongodb.net/?retryWrites=true&w=majority&appName=datauserwabot',
	api: {
		fannn: {
			api_url: 'https://api.sim-c.xyz',
			api_key: 'j{u5d,gZ-}A^`%q(NW'
		},
		caliph: {
			api_url: 'https://api.caliph.biz.id',
			api_key: '9GsGh3qg'
		},
		beta: {
			api_url: 'https://tools.betabotz.eu.org'
		},
		skizo: {
			api_url: 'https://skizo.tech',
			api_key: 'kontolkuda085'
		},
		neo: {
			api_url: 'https://api.neoxr.my.id',
			api_key: 'lcgpQhjNFG'
		},
		ae: {
			api_url: 'https://widipe.com'
		},
		itzpire: {
			api_url: 'https://itzpire.com'
		},
		popcat: {
			api_url: 'https://api.popcat.xyz'
		}
	},
	bot: {
		name: '𝙈𝙖𝙘𝙝𝙤𝘽𝙊𝙏⚡',
		/*profile_status: 'I am 𝙈𝙖𝙘𝙝𝙤𝘽𝙊𝙏⚡, I am ready to serve you',*/
		caption: 'I am 𝙈𝙖𝙘𝙝𝙤𝘽𝙊𝙏⚡, I am ready to serve you'
	},
	gpt: {
		url1: 'https://i.ibb.co.com/tstWhpd/1000034331.jpg',
		url2: 'https://i.ibb.co.com/gdFCM0S/IMG-20240702-060000.jpg'
	},
	owner: {
		name: ["Fannn."],
		number: ["6285336603330"]
	},
	daily_limit: {
		free: 25,
		premium: Infinity
	},
	watermark: {
		sticker: {
			package_name: 'Created by',
			author_name: '𝙈𝙖𝙘𝙝𝙤𝘽𝙊𝙏⚡'
		}
	},
	react: {
		process: '🕒', // Proses
		success: '✅', // Done
		failed: '❗', // Fail
		noregist: '❓', // Not Registered
		limit: '⛔', // Limit
		noowner: '🛡️', // Fitur Owner
		similarity: '🤷🏻' //Kemiripan
	},
	cron_jobs: {
		time: '0 0 * * *',
		timzone: 'Asia/Jakarta'
	},
	message: {
		plans_and_pricing: '*Plans & Pricing*\n\n*Plan:*\n- Free (benefit): Limit 25/day\n- Premium (benefit): Limit infinity/unlimited\n\n*Price:*\n- Premium 7 hari: 3rb\n- Premium 14 hari: 5rb\n- Premium 1 bulan 10rb\n- Premium 2 bulan: 20rb\n- Premium 1 tahun: 120rb\n\n*Contact owner:* wa.me//6285336603330\n\nJangan Lupa kunjungi Web API Provider Kami🥳\n\nLink : https://api.sim-c.xyz',
		not_registered: 'Anda belum terdaftar sebagai pengguna. Untuk mendaftar, ketik: *.register*\n\n*Example* : .register namakamu',
		especially_premium: 'Anda harus memiliki akun Premium untuk mengakses fitur ini.',
		especially_owners: 'Anda tidak diizinkan mengakses fitur ini.',
		daily_limit: 'Maaf, limit harian Anda telah habis. Limit akan direset setiap pukul jam 00.00 WIB.',
		large_file: 'Type Akun: Free memiliki batas pengunduhan maximal 300 MB'
	},
	date: {
		country: 'id-ID',
		time_zone: 'Asia/Jakarta'
	}
}