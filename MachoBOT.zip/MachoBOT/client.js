/*
 * Source: My Personal Script
 * Information
 * Modified By: Muh*** Irf** M*r** (Fannn.)
 * Contact Modified: 0853 3660 3330 (WhatsApp)
 * DICK CUTTING BEWARE
 */
/*
 * Update Information : Menggunakan Scraper
 */

const {
	default: makeWASocket,
	useMultiFileAuthState,
	DisconnectReason,
	makeInMemoryStore,
	msgRetryCounterMap,
	proto,
	downloadMediaMessage,
	downloadContentFromMessage,
	makeCacheableSignalKeyStore,
	MessageType,
	Mimetype,
	getContentType,
	generateWAMessage,
	generateWAMessageFromContent,
	generateForwardMessageContent,
	generateThumbnail,
	extractImageThumb,
	prepareWAMessageMedia,
	WAMessageProto,
	delay,
	jidDecode,
	getAggregateVotesInPollMessage
} = require("@whiskeysockets/baileys");

const fs = require('fs');
const util = require('util');
const axios = require('axios');
const difflib = require('difflib');
const path = require('path');
const chalk = require('chalk');
const mongoose = require('mongoose');
const request = require('request');
const fetch = require('node-fetch');
const os = require('os');
const speed = require('performance-now');
const {
	performance
} = require('perf_hooks');
const {
	sizeFormatter
} = require('human-readable');

// Scraper Area
const {
	ytdown
} = require("nayan-media-downloader");
const {
	alldown
} = require("nayan-media-downloader");
const Nishino = require('nishino-project');
const {
	alldl
} = require('rahad-all-downloader');
const {
	ytmp4
} = require('ruhend-scraper');
const {
	tozombie
} = require('ruhend-scraper');
const {
	instagramdl
} = require('@bochilteam/scraper');
const {
	snapsave
} = require('@bochilteam/scraper-snapsave');
// End

const {
	exec,
	spawn,
	execSync
} = require("child_process");

const config = require('./config/mainConfig.js');
const {
	imageUploader
} = require('./utils/functionsUtils.js');
const {
	suggestCommand
} = require('./utils/functionsUtils.js');
const {
	cleanCommands,
	teamInsinder
} = require('./models/CommandFannn.js');

const now = new Date();
const hours = now.getHours();
const minutes = now.getMinutes();
const seconds = now.getSeconds();
const date = now.getDate();
const month = now.getMonth() + 1;
const year = now.getFullYear();

const formateTime = `${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds} WIB, ${date < 10 ? '0' : ''}${date}-${month < 10 ? '0' : ''}${month}-${year}`;

const formattedDate = new Date(date.toLocaleString('en-US', {
	timeZone: config.date.time_zone
}));

const currentDate = formateTime;
const currentDate1 = formattedDate;

const asiaWib = `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes} WIB, ${date < 10 ? '0' : ''}${date}-${month < 10 ? '0' : ''}${month}-${year}`;

const {
	getCurrentGreeting
} = require('./utils/functionsUtils.js');
const greeting = getCurrentGreeting();
const currentHour = new Date().getHours();

const {
	getRmasIcan,
	generateFilename,
	getMimeType,
	getFileExtension,
	randomGroupname
} = require('./utils/functionsUtils.js');

/*
 Filename Diperlukan
 const typefile = getMimeType(fileName);
					const extension = getFileExtension(typefile);
					const generateFN = getRmasIcan() + generateFilename(6) + '.' + extension;
*/
const {
	isPremiumUser,
	checkFileSize,
	getRandomQuality,
	getRandomMerror,
	formatViews,
	formatDuration,
	formatSize,
	formatDate
} = require('./utils/functionsUtils.js');
const qualityy = getRandomQuality();
const errorCookk = getRandomMerror();

async function mainFunction({
	client,
	messages,
	userSchema
}) {
	try {
		const message = messages.message;
		const messageType = messages.type;
		const messageMType = messages.mtype;
		const messageContent = JSON.stringify(message);
		const messageKey = messages.key;
		const messageChat = messages.chat;
		const messageSender = messages.sender;
		const messagePushName = messages.pushName;
		const messageReply = messages.reply;
		const body = messageMType === 'conversation' ? message.conversation : messageMType === 'extendedTextMessage' ? message.extendedTextMessage.text : messageMType === 'imageMessage' ? message.imageMessage.caption : messageMType === 'videoMessage' ? message.videoMessage.caption : '';
		const budy = typeof messages.text === 'string' ? messages.text : '';
		const command = body.startsWith(config.prefix) ? body.replace(config.prefix, '').trim().split(/ +/).shift().toLowerCase() : '';
		const cleanCommand = command.replace(config.prefix, '');
		const args = body.trim().split(/ +/).slice(1);
		const query = q = args.join(' ');
		const query1 = q1 = query.split('|')[0];
		const query2 = q2 = query.split('|')[1];
		const quoted = messages.quoted ? messages.quoted : messages;
		const qmsg = (quoted.msg || quoted);
		const mime = (quoted.msg || quoted).mimetype || '';
		const isMedia = /image|video|sticker|audio/.test(mime);
		const isImage = (messageType == 'imageMessage');
		const isVideo = (messageType == 'videoMessage');
		const isAudio = (messageType == 'audioMessage');
		const isText = (messageType == 'textMessage');
		const isSticker = (messageType == 'stickerMessage');
		const isQuotedText = messageType === 'extendexTextMessage' && messageContent.includes('textMessage');
		const isQuotedImage = messageType === 'extendedTextMessage' && messageContent.includes('imageMessage');
		const isQuotedLocation = messageType === 'extendedTextMessage' && messageContent.includes('locationMessage');
		const isQuotedVideo = messageType === 'extendedTextMessage' && messageContent.includes('videoMessage');
		const isQuotedSticker = messageType === 'extendedTextMessage' && messageContent.includes('stickerMessage');
		const isQuotedAudio = messageType === 'extendedTextMessage' && messageContent.includes('audioMessage');
		const isQuotedContact = messageType === 'extendedTextMessage' && messageContent.includes('contactMessage');
		const isQuotedDocument = messageType === 'extendedTextMessage' && messageContent.includes('documentMessage');
		const jid = messageChat ? messageChat : messageKey.remoteJid;
		const senderNumber = messageSender.replace(/\D/g, '');
		const senderName = messagePushName || 'Undefined';
		const ownerNumbers = config.owner.number;
		const isOwner = ownerNumbers.includes(senderNumber);
		const insiderNumbers = teamInsinder;
		const isInsider = insiderNumbers.includes(senderNumber);
		const profileStatus = config.bot.caption;
		const isPublicMode = config.public_mode;
		const isOfflineStatus = config.offline_status;
		const isAutoUpdateProfileStatus = config.auto_update_profile_status;
		const isMessage = message;
		const isAutoReadMessages = config.auto_read_messages;
		const isAutoTyping = config.auto_typing;
		const isAutoRecording = config.auto_recording;
		const isGroup = messages.isGroup;

		let groupMetadata;
		let isAdmin;

		if (isGroup) {
			groupMetadata = await client.groupMetadata(jid);
			isAdmin = groupMetadata.participants.find(participant => participant.id === messageSender && participant.admin !== null);
		};

		//var reply = sendText = messageReply;
		const formateReply = `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds} WIB`;

		const ctlg = {
			key: {
				fromMe: false,
				participant: "0@s.whatsapp.net",
				remoteJid: "0@s.whatsapp.net"
			},
			message: {
				extendedTextMessage: {
					text: 'Rp1,999,999,99'
				}
			}
		}

		// Show Item
		/*message: { 
		        orderMessage: { 
		            itemCount: 999999, // Remove this line
		            surface: 'CATALOG',
		            orderTitle: 'Harga',  // Title for the price
		            sellerJid: "0@s.whatsapp.net", 
		            thumbnail: fs.readFileSync('./config/thumb.jpg'),
		            description: 'Total Harga: Rp999,999',  // Directly showing the price
		            currencyCode: 'IDR',
		            totalAmount1000: 999999000 // Representing price in minor currency units (cents)
		        }
		    }*/
		    
		    const reply = (text) => {
			client.sendMessage(jid, {
				text: text,
				contextInfo: {
					externalAdReply: {
						title: `${greeting}`,
						showAdAttribution: true,
						body: `${formateReply}`,
						previewType: 'PHOTO',
						thumbnail: fs.readFileSync('./src/image/thumb.jpg'),
						sourceUrl: 'https://www.instagram.com/hey.irpan?igsh=MTZlcDhnOGwyY2J1Yw=='
					}
				}
			}, {
				quoted: messages
			});
		}
		
		    const reply2 = (text) => {
			client.sendMessage(jid, {
				text: text,
				contextInfo: {
					/*forwardingScore: 999, 
					isForwarded: true,*/
					externalAdReply: {
						title: `${greeting}`,
						previewType: 'PHOTO',
						body: `${formateReply}`,
						thumbnail: fs.readFileSync('./src/image/thumb.jpg'),
						sourceUrl: 'https://www.instagram.com/hey.irpan?igsh=MTZlcDhnOGwyY2J1Yw=='
					}
				}
			}, {
				quoted: ctlg // messages & ctlg
			});
		}
		
		const User = userSchema;

		if (!isPublicMode) {
			if (!messageKey.fromMe) {
				return;
			}
		};

		if (config.mode === 'private') {
			if (isMessage) {
				if (isGroup) {
					return;
				};
			};
		} else if (config.mode === 'group') {
			if (isMessage) {
				if (!isGroup) {
					return;
				};
			};
		} else if (config.mode === 'all' || config.mode === 'both') {
			/* */
		};

		// Offline status
		if (isOfflineStatus) {
			client.sendPresenceUpdate('unavailable', jid)
		};

		// Auto update profile status
		if (isAutoUpdateProfileStatus) {
			client.updateProfileStatus(profileStatus)
		};

		if (isMessage) {
			if (body.startsWith(config.prefix)) {

				// Auto read messages
				if (isAutoReadMessages) {
					client.readMessages([messageKey]);
				};

				// Auto typing
				if (isAutoTyping) {
					client.sendPresenceUpdate('composing', jid)
				};

				// Auto recording
				if (isAutoRecording) {
					client.sendPresenceUpdate('recording', jid)
				};

			};

			console.log(
				chalk.bgMagenta(' [New Message] '),
				chalk.cyanBright('Time: ') + chalk.greenBright(currentDate) + '\n',
				chalk.cyanBright('Message: ') + chalk.greenBright(budy || messageMType) + '\n' +
				chalk.cyanBright('From:'), chalk.greenBright(senderName), chalk.yellow('- ' + senderNumber) + '\n' +
				chalk.cyanBright('Chat Type:'), chalk.greenBright(!isGroup ? 'Private Chat' : 'Group Chat - ' + chalk.yellow(messageChat))
			);
		};

		if (!body.startsWith(config.prefix) || body === config.prefix) {
			return;
		};

		const sendStickerFromUrl = async (to, url) => {
			var names = Date.now() / 10000;
			var download = function(uri, filename, callback) {
				request.head(uri, function(err, res, body) {
					request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
				});
			};
			download(url, './stik' + names + '.png', async function() {
				console.log('selesai');
				let filess = './stik' + names + '.png'
				let asw = './stik' + names + '.webp'
				exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
					let media = fs.readFileSync(asw)
					client.sendImageAsSticker(to, media, messages, {
						packname: config.watermark.sticker.package_name,
						author: config.watermark.sticker.author_name
					});
					fs.unlinkSync(filess)
					fs.unlinkSync(asw)
				});
			});
		}

		switch (cleanCommand) {
			case 'test1': {
				reply('Done')
				break;
			};

			case 'testm': {
				client.sendTextWithMentions(jid, `Halo @${messages.sender.split('@')[0]}

no: ${messages.sender.split('@')[0]}

@6282320667363`, quoted);
				break;
			};

			case 'testcok': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				}

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://vt.tiktok.com/ZSN6SJLPA/`);
				}

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const data = await instagramdl(query);
					console.log(data);
					const {
						thumbnail,
						url,
						type
					} = data;

				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'runtime':
			case 'uptime': {
				const upTime = process.uptime()
				const runTime = client.runTime(upTime)
				reply(runTime)
				break;
			};

			case 'ping':
			case 'server':
			case 'botstatus':
			case 'statusbot': {
				if (isOwner) {
					const used = process.memoryUsage();
					const cpus = os.cpus().map(cpu => {
						cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
						return cpu;
					});

					const cpu = cpus.reduce((last, cpu, _, {
						length
					}) => {
						last.total += cpu.total;
						last.speed += cpu.speed / length;
						last.times.user += cpu.times.user;
						last.times.nice += cpu.times.nice;
						last.times.sys += cpu.times.sys;
						last.times.idle += cpu.times.idle;
						last.times.irq += cpu.times.irq;
						return last;
					}, {
						speed: 0,
						total: 0,
						times: {
							user: 0,
							nice: 0,
							sys: 0,
							idle: 0,
							irq: 0
						}
					});

					let timestamp = speed();
					let latensi = speed() - timestamp;
					neww = performance.now();
					oldd = performance.now();

					const formatp = sizeFormatter({
						std: 'JEDEC', //'SI' = default | 'IEC' | 'JEDEC'
						decimalPlaces: 2,
						keepTrailingZeroes: false,
						render: (literal, symbol) => `${literal} ${symbol}B`,
					})

					respon = `Kecepatan Respon ${latensi.toFixed(4)} _Second_
${oldd - neww} _miliseconds_

RunTime: ${client.runTime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}

_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
  `.trim();
					client.sendImageMessage(jid, `Server Status`, `${greeting}`, config.gw_url, config.server_url, respon, true, true, quoted);
				} else {
					const reactionMessageOwner = {
						react: {
							text: config.react.noowner,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageOwner);
					reply(config.message.especially_owners);
				}
				break;
			};

			case 'test': {
				reply('Oke, Aman Cuy👌🏻');
				break;
			};

			case 'toaudio': {
				if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Send/Reply Video/Audio that you want to make into audio with caption ${config.prefix + cleanCommand}`);
				let media = await client.downloadAndSaveMediaMessage(messages, 'video', `./temp/${Date.now()}.mp4`);
				const getRandom = (ext) => {
					return `${Math.floor(Math.random() * 10000)}${ext}`
				}
				let ran = './temp/' + getRandom('.mp3')
				exec(`ffmpeg -i ${media} ${ran}`, async (err) => {
					fs.unlinkSync(media)
					if (err) {
						fs.unlinkSync(ran);
						return reply(err)
					}
					client.sendMessage(jid, {
						audio: fs.readFileSync(ran),
						mimetype: 'audio/mp4',
						fileName: `${messageSender.split("@")[0]}ToMp3`,
						ptt: args[1] == '--ptt' ? true : false
					}, {
						quoted: quoted
					})
					fs.unlinkSync(ran)
				})
			}
			break;

			case 'owner': {
				let list = []
				for (let i = 0; i < config.owner.number.length; i++) {
					list.push({
						displayName: `${config.owner.name}`,
						vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${config.owner.name};;;${i+1};\nFN:${config.owner.name}\nitem1.TEL;waid=${config.owner.number[i]}:${config.owner.number[i]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
					})
				}
				await client.sendMessage(jid, {
					contacts: {
						displayName: `${list.length} kontak`,
						contacts: list
					}
				})
				break;
			};

			case 'upgrade':
			case 'upgradeaccount':
			case 'plan':
			case 'plans':
			case 'price':
			case 'pricing':
			case 'plansandpricing':
			case 'pap': {
				reply(config.message.plans_and_pricing);
				break;
			};

			// Menu area
			case 'menu':
			case 'mainmenu': {
				const phoneNumber = senderNumber;
				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				}

				const phoneNumberDigitsOnly = user.phoneNumber.replace(/\D/g, '');
				const dailyLimit = user.accountType === 'Premium' ? 'Infinity' : user.dailyLimit;

				const menu = `*☁️ Your information*
> *Username:* ${user.username}
> *Phone Number:* @${phoneNumberDigitsOnly}
> *Account Type:* ${user.accountType}
> *Daily Limit:* ${dailyLimit}

*🚀 RunTime:* \`\`\`${client.runTiime(process.uptime())}\`\`\`

*🧾 Main Menu*
> \`\`\`${config.prefix}allmenu\`\`\`
> \`\`\`${config.prefix}ai\`\`\`
> \`\`\`${config.prefix}downloader\`\`\`
> \`\`\`${config.prefix}searcher\`\`\`
> \`\`\`${config.prefix}stalker\`\`\`
> \`\`\`${config.prefix}maker\`\`\`
> \`\`\`${config.prefix}urlshortener\`\`\`
> \`\`\`${config.prefix}converter\`\`\`
> \`\`\`${config.prefix}tools\`\`\`
> \`\`\`${config.prefix}auth\`\`\``;

				console.log(getCurrentGreeting());
				client.sendMessage(jid, {
      text: menu,
      //mentions: [phoneNumberDigitsOnly + '@s.whatsapp.net'],
      mentions: [...menu.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
      contextInfo: {
					externalAdReply: {
						title: `Hello👋🏻, ${greeting}`, `${asiaWib}`,
						body: `${asiaWib}`,
						sourceUrl: config.gw_url,
						thumbnailUrl: config.image_url,
						mediaType: 1,
						renderLargerThumbnail: true,
						showAdAttribution: true
					}
				}
   }, {
      quoted
   });
   
				//client.sendImageMessage(jid, `Hello👋🏻, ${greeting}`, `${asiaWib}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'ai':
			case 'aimenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available AI Features\`
> openai [text]
> chatgpt4 [text]
> googlebard [text]
> simsimi [text]
> chattyai [text]
> midjourney [text]`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `AI Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'downloader':
			case 'downloadermenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available Downloader Features\`
> tiktokvideo [url]
> tiktokvideov2 [url]
> tiktokslide [url]
> tiktokaudio [url]
> youtubevideo [url]
> youtubeaudio [url]
> facebook [url]
> mediafire [url]
> googledrive [url]`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `Downloader Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'searcher':
			case 'searchermenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available Searcher Features\`
> youtubesearch [text]
> lyrics [text]
> stackoverflow [text]
> whatsappgroup [text]
> googleimage [text]`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `Searcher Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'stalker':
			case 'stalkermenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available Stalker Features\`
> tiktokstalk [username]
> githubuser [username]
> githubrepo [username|repo name]
> npmjspackage [package name]
> ipstalk [ip address]`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `Stalker Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'maker':
			case 'makermenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available Maker Features\`
> emojimix [emoji1|emoji2]
> remini [image]
> removebg [image]
> animefilter [image]
> zombiefilter [image]
> upscale [image]
> beautiful [image]
> blur [image]
> invert [image]
> rainbow [image]
> trigger [image]
> wanted [image]
> wasted [image]
> darkness [image|volume]
> pixelate [image|volume]`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `Maker Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'urlshortener':
			case 'us':
			case 'urlshortenermenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available URL Shortener Features\`
> bitly [url]
> cuttly [url]
> tinyurl [url]
> tinyurlwithalias [url|alias]
> tinyurlresolve [url]`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `URL Shortener Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'converter':
			case 'convert':
			case 'convertermenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available Converter Features\`
> texttoimage [text]
> texttogif [text]
> texttospeech [text|language]
> imagetourl [image]
> sticker [image|video]
> stickermeme [image]`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `Converter Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'tools':
			case 'tool':
			case 'toolsmenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available Tools Features\`
> whois [domain]
> translate [text|language]
> tempmail
> tempmailinbox [id]
> screenshotwebsite [url|device]
> fetch [url]`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `Tools Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'auth':
			case 'authmenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Available Authentication Features\`
> register
> myinfo
> checklimit`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `Authentication Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'adminmenu':
			case 'ownermenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const menu = `\`Mau Ngapain Tod??\`
> showdata
> deleteprem
> addprem
> deleteuser
> deleteallusers
> deletemessage
> creategroup`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `Owner Menu`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			case 'all':
			case 'allmenu': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				const phoneNumberDigitsOnly = user.phoneNumber.replace(/\D/g, '');
				const dailyLimit = user.accountType === 'Premium' ? 'Infinity' : user.dailyLimit;

				const menu = `\`Your information\`
> *Username:* ${user.username}
> *Phone Number:* @${phoneNumberDigitsOnly}
> *Account Type :* ${user.accountType}
> *Daily Limit:* ${dailyLimit}

\`Available AI Features\`
> openai [text]
> chatgpt4 [text]
> googlebard [text]
> simsimi [text]
> chattyai [text]
> midjourney [text]

\`Available Downloader Features\`
> tiktokvideo [url]
> tiktokvideov2 [url]
> tiktokslide [url]
> tiktokaudio [url]
> youtubevideo [url]
> youtubeaudio [url]
> facebook [url]
> mediafire [url]
> googledrive [url]

\`Available Searcher Features\`
> youtubesearch [text]
> lyrics [text]
> stackoverflow [text]
> whatsappgroup [text]
> googleimage [text]

\`Available Stalker Features\`
> tiktokstalk [username]
> githubuser [username]
> githubrepo [username|repo name]
> npmjspackage [package name]
> ipstalk [ip address]

\`Available Maker Features\`
> emojimix [emoji1|emoji2]
> remini [image]
> removebg [image]
> animefilter [image]
> zombiefilter [image]
> upscale [image]
> beautiful [image]
> blur [image]
> invert [image]
> rainbow [image]
> trigger [image]
> wanted [image]
> wasted [image]
> darkness [image|volume]
> pixelate [image|volume]

\`Available URL Shortener Features\`
> bitly [url]
> cuttly [url]
> tinyurl [url]
> tinyurlwithalias [url|alias]
> tinyurlresolve [url]

\`Available Converter Features\`
> texttoimage [text]
> texttogif [text]
> texttospeech [text|language]
> imagetourl [image]
> sticker [image|video]
> stickermeme [image]

\`Available Tools Features\`
> whois [domain]
> translate [text|language]
> tempmail
> tempmailinbox [id]
> screenshotwebsite [url|device]
> fetch [url]

\`Available Authentication Features\`
> register
> myinfo
> checklimit`;

				console.log(getCurrentGreeting());
				client.sendImageMessage(jid, `All Features`, `${greeting}`, config.gw_url, config.image_url, menu, true, true, quoted);
				break;
			};

			// Features area
			// AI
			case 'openai': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				}

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Hello, AI`);
				}

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/openaiv2?apikey=' + apiKey + '&text=' + query + '&system=openai');
						return data.json();
					};

					const data = await fetchData(config.api.skizo.api_url, config.api.skizo.api_key, query);
					if (!data) return reply('Not found');
					const response = data.result;

					const hasil = `*Results:*\n${response}`;

					client.sendImageMessage(jid, 'OpenAI', `${asiaWib}`, config.linkgc, config.gpt.url1, hasil, true, true, quoted).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						}
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				}
				break;
			};

			case 'chatgpt4':
			case 'cgpt4': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				}

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Hello, AI`);
				}

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/openaiv2?apikey=' + apiKey + '&text=' + query + '&system=chatgpt4o');
						return data.json();
					};

					const data = await fetchData(config.api.skizo.api_url, config.api.skizo.api_key, query);
					if (!data) return reply('Not found');
					const response = data.result;

					const hasil = `*Results:*\n${response}`;

					client.sendImageMessage(jid, 'ChatGPT 4o', `${asiaWib}`, config.linkgc, config.gpt.url1, hasil, true, true, quoted).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						}
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				}
				break;
			};

			case 'googlebard':
			case 'gbard':
			case 'bard': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Hello, AI`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, query, apiKey) {
						const data = await fetch(apiUrl + '/api/bard?q=' + query + '&apikey=' + apiKey);
						return data.json();
					};

					const data = await fetchData(config.api.neo.api_url, query, config.api.neo.api_key);
					if (!data) return reply('Not found');
					const response = data.data.message;

					//console.log(data);
					const hasil = `*Results:*\n${response}`;

					client.sendImageMessage(jid, 'Google Bard', `${asiaWib}`, config.linkgc, config.gpt.url2, hasil, true, true, quoted).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'simsimi':
			case 'simi': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Hello, AI`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/artificial-intelligence/simsimi?api_key=' + apiKey + '&language=id&question=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					const response = data.data.answer;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'chattyai':
			case 'chatty': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Hello, AI`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/artificial-intelligence/chatty-ai?api_key=' + apiKey + '&question=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					const response = data.data.answer;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'midjourney':
			case 'mj': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (user.accountType !== 'Premium') {
					reply(config.message.especially_premium);
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} A cat`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/artificial-intelligence/midjourney?api_key=' + apiKey + '&text=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			// Downloader


			case 'tiktok':
			case 'tiktokvideo':
			case 'tt':
			case 'ttmp4': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				}

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://vt.tiktok.com/ZSN6SJLPA/`);
				}

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const response = await fetch(apiUrl + '/api/tiktok?apikey=' + apiKey + '&url=' + query);
						const data = await response.json();
						return data;
					}

					const data = await fetchData(config.api.skizo.api_url, config.api.skizo.api_key, query);
					if (!data) return reply('Not found');

					const {
						title,
						hdplay,
						play_count,
						digg_count,
						comment_count,
						share_count,
						download_count
					} = data.data;
					const {
						unique_id,
						nickname,
						avatar
					} = data.data.author;
					const video_url = hdplay;
					const response = `*【 TIKTOK DOWNLOADER 】*\n\n*❏ Author* : ${nickname}\n*❏ Username* : _@${unique_id}_\n*❏ Caption* : ${title}\n\n${config.pro}`

					console.log(response);

					client.sendImageMessage(jid, 'TIKTOK DOWNLOADER', `Create by : @${unique_id}`, query, avatar, response, true, true, quoted);

					const generateFN = getRmasIcan() + generateFilename(6);

					setTimeout(() => {
						client.sendMessage(jid, {
							document: {
								url: video_url
							},
							fileName: generateFN + '.mp4',
							caption: `${config.caption}`,
							mimetype: 'video/mp4'
						}, {
							quoted: messages
						}).then(() => {
							const reactionMessageCompleted = {
								react: {
									text: config.react.success,
									key: messageKey,
								},
							};
							client.sendMessage(jid, reactionMessageCompleted);

							if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
								user.dailyLimit -= 1;
								user.save();
							}
						}).catch((error) => {
							const errorMessage = `Error: ${error.message}`;
							reply(errorCookk);
							console.error(errorMessage);
						});
					}, 5000);
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				}
				break;
			};

			case 'tiktokv2':
			case 'tiktokvideov2':
			case 'tt2':
			case 'ttmp4v2': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				}

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://vt.tiktok.com/ZSN6SJLPA/`);
				}

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const response = await fetch(apiUrl + '/api/tiktok?apikey=' + apiKey + '&url=' + query);
						const data = await response.json();
						return data;
					}

					const data = await fetchData(config.api.skizo.api_url, config.api.skizo.api_key, query);
					if (!data) return reply('Not found');

					const {
						title,
						hdplay,
						play_count,
						digg_count,
						comment_count,
						share_count,
						download_count
					} = data.data;
					const {
						unique_id,
						nickname,
						avatar
					} = data.data.author;
					const video_url = hdplay;
					const response = `*【 TIKTOK DOWNLOADER 】*\n\n*❏ Author* : ${nickname}\n*❏ Username* : _@${unique_id}_\n*❏ Caption* : ${title}\n`

					console.log(response);
					client.sendImageMessage(jid, 'TIKTOK DOWNLOADER', `Create by : @${unique_id}`, query, avatar, response, true, true, quoted);

					const fileName = `${asiaWib}.mp4`;

					client.sendMessage(jid, {
						video: {
							url: video_url
						},
						caption: `${config.caption}`,
						mimetype: 'video/mp4'
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						}
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				}
				break;
			};

			case 'tiktokslide':
			case 'tiktokfoto':
			case 'ttslide': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://vt.tiktok.com/ZSN6SJLPA/`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, query) {
						const response = await fetch(apiUrl + '/download/tiktokslide?url=' + query);
						if (!response.ok) throw new Error('Network response was not ok');
						return response.json();
					};

					const data = await fetchData(config.api.ae.api_url, query);
					if (!data || !data.result) return reply('Not found');

					const {
						images
					} = data.result;
					if (!images || images.length === 0) return reply('No images found');

					// Mengirim pesan ke private chat pengguna bot
					const userJid = user.phoneNumber + '@s.whatsapp.net';

					for (let i = 0; i < images.length; i++) {
						const image_url = images[i];
						await client.sendMessage(userJid, {
							document: {
								url: image_url
							},
							fileName: `${i + 1}.jpg`,
							mimetype: 'image/jpeg'
						}, {
							quoted: messages
						});
					}

					// Beri tahu pengguna di grup bahwa file sudah dikirim ke private chat
					const response = `*File Berhasil dikirim ke Private Chat✅*`;
					reply(response);

					const reactionMessageCompleted = {
						react: {
							text: config.react.success,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageCompleted);

					if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
						user.dailyLimit -= 1;
						await user.save();
					};

				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'tiktokaudio':
			case 'sound':
			case 'ttmp3': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://vt.tiktok.com/ZSN6SJLPA/`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, query) {
						const response = await fetch(`${apiUrl}/tools/tiktokdl?url=${query}`);
						if (!response.ok) {
							throw new Error('Network response was not ok');
						}
						return response.json();
					};

					const data = await fetchData(config.api.beta.api_url, query);

					if (!data || !data.result || !data.result.data || !data.result.data.music_info) {
						return reply('Not found or invalid response structure');
					}

					const {
						title,
						play,
						cover,
						author
					} = data.result.data.music_info;

					const audio_url = play;
					const response = `${config.pro}`;

					console.log(data.result);
					const typefile = getMimeType(audio_url);
					const extension = getFileExtension(typefile);
					const generateFN = getRmasIcan() + generateFilename(6) + '.' + extension;

					setTimeout(() => {
						client.sendImageMessage(jid, 'TIKTOK DOWNLOADER', `Create by : ${author}`, query, cover, response, true, true, quoted);

						client.sendMessage(jid, {
							document: {
								url: audio_url
							},
							fileName: generateFN,
							caption: `${config.caption}`,
							mimetype: typefile
						}, {
							quoted: messages
						}).then(() => {
							const reactionMessageCompleted = {
								react: {
									text: config.react.success,
									key: messageKey,
								},
							};
							client.sendMessage(jid, reactionMessageCompleted);

							if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
								user.dailyLimit -= 1;
								user.save();
							}
						}).catch((error) => {
							const errorMessage = `Error: ${error.message}`;
							reply(errorCookk);
							console.error(errorMessage);
						});
					}, 5000);
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'youtube':
			case 'youtubevideo':
			case 'yt': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://youtu.be/HEFBezb8XgQ?si=wN_hT_nydnnzVNnw`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					Nishino.download.youtube_dl_mp4(query)
						.then(data => {
							console.log(data)

							const {
								title,
								description,
								length_seconds,
								owner_rofile_url,
								external_channel_id,
								thumb,
								channel,
								published,
								views,
								category,
								url
							} = data.result;
							// Beberapa Perubahan Manual
							const dateString = `${published}`;
							const upload = formatDate(dateString);

							const formattedViews = formatViews(views);
							const formattedDuration = formatDuration(length_seconds);

							const response = `> *Channel:* _${channel}_\n> *Duration:* _${formattedDuration}_\n> *Views:* _${formattedViews}_\n> *Category:* _${category}_\n> *Upload:* _${upload}_\n\n${config.pro}`;

							client.sendImageMessage(jid, `${title}`, `${description}`, query, `${thumb}`, response, true, true, quoted);
						});

					const {
						title,
						video,
						quality,
						thumbnail,
						size
					} = await ytmp4(query);
					console.log(quality);

					const generateFN = getRmasIcan() + generateFilename(6);

					client.sendMessage(jid, {
						document: {
							url: video
						},
						fileName: generateFN + '.mp4',
						caption: `${config.caption}`,
						mimetype: 'video/mp4'
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'youtubeaudio':
			case 'ytaudio':
			case 'ytmp3': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://youtube.com/shorts/_qpLKV-cflE?si=KBk6zFJyBpbhecmI`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					/*async function fetchData(apiUrl, query, apiKey) {
						const data = await fetch(`${apiUrl}/api/youtube?url=${query}&type=audio&quality=128kbps&apikey=${apiKey}`);
						return data.json();
					};

					const data = await fetchData(config.api.neo.api_url, query, config.api.neo.api_key);
					if (!data) return reply('Not found');
					console.log(data);*/
					Nishino.download.youtube_dl_mp3(query)
						.then(data => {
							console.log(data)
							const {
								title,
								description,
								length_econds,
								thumb,
								channel,
								published,
								views,
								url
							} = data.result;
							const formattedViews = formatViews(views);
							const formattedDuration = formatDuration(length_seconds);

							const response = `> *Duration:* _${formattedDuration}_\n> *Views:* _${formattedViews}_\n> *Upload:* _${published}_\n\n${config.pro}`;

							client.sendImageMessage(jid, `${title}`, `${channel}`, query, `${thumb}`, response, true, true, quoted);
						});

					let URL = await ytdown(query);
					console.log(URL);

					const {
						video
					} = URL.data;
					console.log(video);

					const generateFN = getRmasIcan() + generateFilename(6);

					await client.sendMessage(jid, {
						document: {
							url: video
						},
						fileName: generateFN + '.mp3',
						caption: `${config.caption}`,
						mimetype: 'audio/mpeg'
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'facebook':
			case 'fb':
			case 'fbdl': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				}

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://fb.watch/n-YuhJfnGs/?mibextid=Nif5oz`);
				}

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const generateFN = getRmasIcan() + generateFilename(6);

					const data = await snapsave(query);
					console.log(data);
					const {
						resolution,
						thumbnail,
						url
					} = data.results[0];
					const response = `> *Resolution:* ${resolution}\n\n${config.pro}`

					console.log(response);

					client.sendImageMessage(jid, 'FACEBOOK DOWNLOADER', `${asiaWib}`, query, thumbnail, response, true, true, quoted);

					setTimeout(() => {
						client.sendMessage(jid, {
							document: {
								url: url
							},
							fileName: `${generateFN}.mp4`,
							caption: `${config.caption}`,
							mimetype: 'video/mp4'
						}, {
							quoted: messages
						}).then(() => {
							const reactionMessageCompleted = {
								react: {
									text: config.react.success,
									key: messageKey,
								},
							};
							client.sendMessage(jid, reactionMessageCompleted);

							if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
								user.dailyLimit -= 1;
								user.save();
							}
						}).catch((error) => {
							const errorMessage = `Error: ${error.message}`;
							reply(errorCookk);
							console.error(errorMessage);
						});
					}, 10000);
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				}
				break;
			};

			case 'mediafire':
			case 'mf': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://drive.google.com/file/d/11xgPLTvOPsjMbH48tBbvDN0gGyWmnUGD/view`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, query, apiKey) {
						const data = await fetch(apiUrl + '/api/mediafire?url=' + query + '&apikey=' + apiKey);
						return data.json();
					};

					const data = await fetchData(config.api.neo.api_url, query, config.api.neo.api_key);
					if (!data) return reply('Not found');

					const {
						filename,
						size,
						mime,
						uploaded,
						link
					} = data.data;
					const file_size = size;
					const file_url = link;

					console.log(data);

					// Fetch the file to get its buffer and check its size
					const fileResponse = await fetch(file_url);
					const fileBuffer = await fileResponse.buffer();
					const fileSizeMB = fileBuffer.byteLength / (1024 * 1024); // Convert bytes to MB

					// Check file size for free users
					if (!checkFileSize(fileSizeMB, user)) {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						return reply(config.message.large_file);
					}

					const options = {
						document: {
							url: file_url
						},
						fileName: filename,
						caption: `${config.caption}`,
						mimetype: mime
					};
					client.sendMessage(jid, options, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'googledrive':
			case 'gdrive':
			case 'gd': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://drive.google.com/file/d/11xgPLTvOPsjMbH48tBbvDN0gGyWmnUGD/view`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/gdrive?apikey=' + apiKey + '&url=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.skizo.api_url, config.api.skizo.api_key, query);
					if (!data) return reply('Not found');

					const {
						fileName,
						downloadUrl
					} = data;
					const file_url = downloadUrl;
					console.log(data);

					const typefile = getMimeType(fileName);
					const extension = getFileExtension(typefile);
					const generateFN = getRmasIcan() + generateFilename(6) + '.' + extension;

					const options = {
						document: {
							url: file_url
						},
						fileName: fileName,
						caption: `${config.caption}`,
						mimetype: typefile
					};
					client.sendMessage(jid, options, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			// Group
			case 'add': {
				if (!isGroup) {
					reply('This command can only be used in a group.');
				} else if (!isAdmin) {
					reply('This command can only be used by group admins.');
				} else {
					const userToAdd = args[0] + '@s.whatsapp.net';
					await client.groupParticipantsUpdate(jid, [userToAdd], 'add');
					reply(`User ${args[0]} has been added to the group.`);
				}
				break;
			};

			case 'remove':
			case 'kick': {
				if (!isGroup) {
					reply('This command can only be used in a group.');
				} else if (!isAdmin) {
					reply('This command can only be used by group admins.');
				} else {
					if (args.length === 0) {
						reply('Please provide the phone number of the user to remove.');
					} else {
						const userToRemove = messages.mentionedJid[0] ? messages.mentionedJid[0] : messages.quoted ? messages.quoted.sender : query.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
						//const userToRemove = args[0] + '@s.whatsapp.net';

						await client.groupParticipantsUpdate(jid, [userToRemove], 'remove');
						reply(`User ${userToRemove.replace('@s.whatsapp.net', '')} has been removed from the group.`);
					}
				}
				break;
			};

			case 'h':
			case 'tag':
			case 'hidetag': {
				if (!isGroup) {
					reply('This command can only be used in a group.');
				} else if (!isAdmin) {
					reply('This command can only be used by group admins.');
				} else {
					var value = messages.quoted ? messages.quoted.text : query;
					if (!value) return reply('Silahkan reply pesan atau isi pesan, contoh: .hidetag halo');
					var group = await client.groupMetadata(jid);
					var member = group['participants'];
					var mem = [];
					member.map(async adm => {
						mem.push(adm.id.replace('c.us', 's.whatsapp.net'));
					});
					var options = {
						text: value,
						contextInfo: {
							mentionedJid: mem
						},
						quoted: messages
					};
					client.sendMessage(jid, options, value);

				}
				break;
			}

			// Searcher
			case 'pinterest':
			case 'pin': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				}

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} How to coding?`);
				}

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, query, apiKey) {
						const data = await fetch(apiUrl + '/api/pinterest?q=' + query + '&apikey=' + apiKey);
						return data.json();
					}

					const data = await fetchData(config.api.neo.api_url, query, config.api.neo.api_key);
					const response = `\`Query:\` ${query}`;
					console.log(data);

					let arrpost = data.data.slice(0, 4);
					let arrcard = [];

					for (let cardpost of arrpost) {
						let eek = {
							"header": proto.Message.InteractiveMessage.Header.create({
								...(await prepareWAMessageMedia({
									image: {
										url: cardpost
									}
								}, {
									upload: client.waUploadToServer
								})),
								title: `\`PINTEREST\``,
								gifPlayback: true,
								subtitle: '',
								hasMediaAttachment: false
							}),
							"body": {
								"text": `${response}`
							},
							nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
								buttons: [{
										"name": "cta_url",
										"buttonParamsJson": `{"display_text":"Chat Owner","url":"https://wa.me/6285336603330"}`
									},
									{
										"name": "cta_url",
										"buttonParamsJson": `{"display_text":"Join Group","url":"https://s.id/MachoBOT"}`
									}
								]
							})
						};
						arrcard.push(eek);
						await delay(2000);
					}

					let ctamsg = generateWAMessageFromContent(jid, {
						viewOnceMessage: {
							message: {
								"messageContextInfo": {
									"deviceListMetadata": {},
									"deviceListMetadataVersion": 2
								},
								interactiveMessage: proto.Message.InteractiveMessage.create({
									body: {
										text: `${config.caption}`
									},
									carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({
										"cards": arrcard,
										"messageVersion": 1
									})
								})
							}
						}
					}, {});

					await client.relayMessage(ctamsg.key.remoteJid, ctamsg.message, {
						messageId: ctamsg.key.id
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						}
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				}
				break;
			}

			case 'youtubesearcher':
			case 'yts': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Asade Kontol`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/searcher/youtube?api_key=' + apiKey + '&video_title=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');

					const youtubeData = data.data;
					let searcherYoutube = '';

					for (const message of youtubeData) {
						searcherYoutube += `*${message.title}*\n`;
						searcherYoutube += `${message.url}\n`;
						searcherYoutube += `*Channel*: ${message.author.name}\n`;
						searcherYoutube += `*Duration*: ${message.timestamp}\n`;
						searcherYoutube += `${message.views} Viewer\n`;
						searcherYoutube += `*Uploaded*: ${message.ago}\n`;
						searcherYoutube += `■□■□■□■□■□■□■□■□■□■□■□\n\n`;
					}

					const response = `*【 YouTube Searcher 】*\n⋆﹥━━━━━━━━━━━━﹤⋆\n${searcherYoutube}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'lyrics':
			case 'songlyrics': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} 18`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/searcher/lyrics?api_key=' + apiKey + '&song_title=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					const response = `*Song Lyrics*\n*Title:* ${q}\n*Artist:* ${data.data.artist}\n*Lyrics:* ${data.data.lyrics}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'stackoverflow':
			case 'so': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} 18`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/searcher/stack-overflow?api_key=' + apiKey + '&post_title=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					const result = data.data[Math.floor(Math.random() * data.data.length)];
					if (!result) return reply('Not found');
					const {
						id,
						vote,
						answer,
						views,
						link,
						title,
						tags,
						userInfo,
						time
					} = result;

					const response = `*Stack Overflow*\n*Id:* ${id}\n*Vote:* ${vote}\n*Answer:* ${answer}\n*Views:* ${views}\n*Link:* ${link}\n*Title:* ${title}\n*Tags:* ${tags}\n*Upload Date:* ${time}\n*Username:* ${userInfo.username}\n*Reputation:* ${userInfo.reputation}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'whatsappgroup':
			case 'wagroup':
			case 'wg': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} 18`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/searcher/whatsapp-group?api_key=' + apiKey + '&group_name=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					const result = data.data[Math.floor(Math.random() * data.data.length)];
					if (!result) return reply('Not found');
					const response = `*WhatsApp Group*\n*Name:* ${result.nama}\n*Link:* ${result.link}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'googleimage':
			case 'googleimagesearch':
			case 'gis': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} How to coding?`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/searcher/google-image?api_key=' + apiKey + '&gi_search=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					const result = data.data[Math.floor(Math.random() * data.data.length)];
					if (!result) return reply('Not found');

					const caption = `${config.caption}`;

					console.log(result);
					client.sendMessage(jid, {
						image: {
							url: result
						},
						caption: caption,
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			// Stalker
			case 'tiktokstalk':
			case 'ttstalk': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} fannnnfannnnnn`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/stalker/tiktok?api_key=' + apiKey + '&username=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					const response = `*TikTok Stalk*\n*Profile picture:* ${data.data.profile}\n*Name:* ${data.data.name}\n*Username:* ${data.data.username}\n*Followers:* ${data.data.followers}\n*Following:* ${data.data.following}\n*Likes:* ${data.data.likes}\n*Bio:* ${data.data.desc}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'githubuser':
			case 'ghuser': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} fannnnfannnnnn`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/stalker/github-user?api_key=' + apiKey + '&username=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					const response = `*GitHub Stalk*\n*Profile picture:* ${data.data.avatar_url}\n*Name:* ${data.data.name}\n*Username:* ${data.data.login}\n*Followers:* ${data.data.followers}\n*Following:* ${data.data.following}\n*Company:* ${data.data.company}\n*Bio:* ${data.data.bio}\n*Blog:* ${data.data.blog}\n*Location:* ${data.data.location}\n*Email:* ${data.data.email}\n*Twitter:* ${data.data.twitter_username}\n*Public Repos:* ${data.data.public_repos}\n*Public Gits:* ${data.data.public_gists}\n*Created at:* ${data.data.created_at}\n*Updated at:* ${data.data.updated_at}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'githubrepo':
			case 'ghrepo': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query1 || !query2) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} fannn|repo`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query1, query2) {
						const data = await fetch(apiUrl + '/api/stalker/github-repo?api_key=' + apiKey + '&username=' + query1 + '&repo_name=' + query2);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query1, query2);
					if (!data) return reply('Not found');
					const response = `*GitHub Repo Stalk*\n*Name:* ${data.data.name}\n*Full Name:* ${data.data.full_name}\n*Private:* ${data.data.private}\n*Owner:* ${data.data.owner.login}\n*Description:* ${data.data.description}\n*Fork:* ${data.data.fork}\n*Pushed at:* ${data.data.pushed_at}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'npmjspackage':
			case 'npmjs': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} fannnnfannnnnn`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/stalker/npmjs-package?api_key=' + apiKey + '&package_name=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					const response = `*NpmJs Package Stalk*\n*Name:* ${data.data.name}\n*Version:* ${data.data['dist-tags'].latest}\n*Author:* ${data.data.author.name}\n*License:* ${data.data.license}\n*Readme:* ${data.data.readme}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'ipstalk':
			case 'ip': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} fannnnfannnnnn`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/stalker/ip?api_key=' + apiKey + '&ip_address=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					const response = `*IP Address Stalk*\n*Continent:* ${data.data.continent}\n*Country:* ${data.data.country}\n*Cointry code:* ${data.data.countryCode}\n*Region:* ${data.data.regionName}\n*City:* ${data.data.city}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			// Maker
			case 'emojimix':
			case 'em': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query1 || !query2) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} 😲|🔥`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const fetchImage = (apiUrl, apiKey, query1, query2) => {
						return apiUrl + '/api/canvas/emoji-mix?api_key=' + apiKey + '&emoji=' + query1 + '&emoji2=' + query2;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, query1, query2);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'remini':
			case 'hdr': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				// Buka kode ini kalo mau diubah jadi khusus premium

				/*if (user.accountType !== 'Premium') {
					reply(config.message.especially_premium);
					return;
				};*/

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query) => {
						return `${apiUrl}/api/remini?apikey=${apiKey}&url=${query}`;
					};

					const data = await fetchImage(config.api.skizo.api_url, config.api.skizo.api_key, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'removebg': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted);
					const imageData = await imageUploader(media);
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media);

					const fetchImage = async (apiUrl, apiKey, query) => {
						const response = await fetch(`${apiUrl}/api/nobg3?image=${query}&apikey=${apiKey}`);
						const data = await response.json();
						return data;
					};

					const data = await fetchImage(config.api.neo.api_url, config.api.neo.api_key, imageUrl);
					if (!data || !data.data.no_background) return reply('Not found');
					const hasil = data.data.no_background;

					const generateFN = getRmasIcan() + generateFilename(6);

					client.sendMessage(jid, {
						document: {
							url: hasil
						},
						fileName: generateFN + '.png',
						caption: `${config.caption}`,
						mimetype: 'image/png'
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorMessage);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorMessage);
					console.error(errorMessage);
				};
				break;
			};

			case 'animefilter':
			case 'toanime': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (user.accountType !== 'Premium') {
					reply(config.message.especially_premium);
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query) => {
						return `${apiUrl}/api/toanime?apikey=${apiKey}&url=${query}`;
					};

					const data = await fetchImage(config.api.skizo.api_url, config.api.skizo.api_key, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'zombiefilter':
			case 'tozombie': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (user.accountType !== 'Premium') {
					reply(config.message.especially_premium);
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const url = `${imageUrl}`;
					const results = await tozombie(url);
					console.log(results.image_data);

					const hasil = results.image_data;

					client.sendMessage(jid, {
						image: {
							url: hasil
						},
						caption: `${config.caption}`
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'upscale': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				// Buka kode ini kalo mau diubah jadi khusus premium

				if (user.accountType !== 'Premium') {
					reply(config.message.especially_premium);
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, query) => {
						return `${apiUrl}/tools/waifu2x?url=${query}`;
					};

					const data = await fetchImage(config.api.itzpire.api_url, imageUrl);
					if (!data) return reply('Not found');
					const {
						result
					} = data;
					console.log(data);

					client.sendMessage(jid, {
						image: {
							url: result
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'beautiful': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/maker/beautiful?api_key=' + apiKey + '&image_url=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'blur': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, query) => {
						return `${apiUrl}/blur?image=${query}`;
					};

					const data = await fetchImage(config.api.popcat.api_url, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'invert': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/maker/invert?api_key=' + apiKey + '&image_url=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'rainbow': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/maker/rainbow?api_key=' + apiKey + '&image_url=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'trigger': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/maker/trigger?api_key=' + apiKey + '&image_url=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'wanted': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/maker/wanted?api_key=' + apiKey + '&image_url=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'wasted': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/maker/wasted?api_key=' + apiKey + '&image_url=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, imageUrl);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'darkness': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand} 50`);
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand} 50`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query1, query2) => {
						return apiUrl + '/api/maker/darkness?api_key=' + apiKey + '&image_url=' + query1 + '&volume=' + query2;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, imageUrl, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'pixelate': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand} 50`);
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand} 50`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const media = await client.downloadAndSaveMediaMessage(quoted)
					const imageData = await imageUploader(media)
					const imageUrl = util.format(imageData);
					await fs.unlinkSync(media)

					const fetchImage = (apiUrl, apiKey, query1, query2) => {
						return apiUrl + '/api/maker/pixelate?api_key=' + apiKey + '&image_url=' + query1 + '&volume=' + query2;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, imageUrl, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			// Converter
			case 'texttoimage':
			case 'tti': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Fannn.`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/converter/text-to-image?api_key=' + apiKey + '&text=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'texttogif':
			case 'ttg': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Fannnn.`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					const fetchImage = (apiUrl, apiKey, query) => {
						return apiUrl + '/api/converter/text-to-gif?api_key=' + apiKey + '&text=' + query;
					};

					const data = await fetchImage(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `${config.caption}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'texttospeech':
			case 'tts': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query1 || !query2) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Hai semua, perkenalkan, nama saya Irfan.|id-ID`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, apiKey, query1, query2) {
						const data = await fetch(apiUrl + '/api/converter/text-to-speech?api_key=' + apiKey + '&text=' + query1 + '&language=' + query2);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query1, query2);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						audio: {
							url: data.data.audio_url
						},
						mimetype: 'audio/mp4',
						ptt: true
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'telegraph':
			case 'tp':
			case 'imagetourl':
			case 'imgtourl':
			case 'tourl': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!/image/.test(mime)) {
					reply(`Kirim pesan gambar dengan caption ${config.prefix}${cleanCommand}`);
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					const media = await client.downloadAndSaveMediaMessage(quoted)
					const data = await imageUploader(media)
					const response = util.format(data);
					await fs.unlinkSync(media)
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'sticker':
			case 'tosticker':
			case 's': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						reply(config.message.not_registered);
					} else {
						reply(config.message.daily_limit);
					}
					return;
				}

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					if (isImage || /image/.test(mime)) {
						let media = await quoted.download();
						let encmedia = await client.sendImageAsSticker(jid, media, messages, {
							packname: config.watermark.sticker.package_name,
							author: config.watermark.sticker.author_name
						});
						await fs.unlinkSync(encmedia);
					} else if (isVideo || /video/.test(mime) || /image/.test(mime)) {
						if (isVideo && (quoted.msg || quoted).seconds > 10) {
							return reply('Maximum video duration is 10 seconds!');
						} else {
							let media = await quoted.download();
							let encmedia = isVideo ?
								await client.sendVideoAsSticker(jid, media, messages, {
									packname: config.watermark.sticker.package_name,
									author: config.watermark.sticker.author_name
								}) :
								await client.sendImageAsSticker(jid, media, messages, {
									packname: config.watermark.sticker.package_name,
									author: config.watermark.sticker.author_name
								});
							await fs.unlinkSync(encmedia);
						}
					} else {
						reply(`Kirim pesan gambar/video dengan caption ${config.prefix + command}\nDurasi video minimal 1 detik, maximal 10 detik!`);
						return;
					}

					const reactionMessageCompleted = {
						react: {
							text: config.react.success,
							key: messageKey,
						},
					};

					client.sendMessage(jid, reactionMessageCompleted);

					if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
						user.dailyLimit -= 1;
						user.save();
					}
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				}
				break;
			};

			case 'stickermeme':
			case 'smeme': {
				let responnd = `Quote an image or sticker with the 2 texts separated with |`
				if (!/image/.test(mime)) return reply(responnd)
				if (!query) return reply(responnd)

				const text1 = query1 ? query1 : '-';
				const text2 = query2 ? query2 : '-';
				const media = await client.downloadAndSaveMediaMessage(quoted)
				const data = await imageUploader(media)
				const response = util.format(data);

				sendStickerFromUrl(jid, `https://api.memegen.link/images/custom/${encodeURIComponent(text1)}/${encodeURIComponent(text2)}.png?background=${response}`)
				await fs.unlinkSync(media)

				break;
			};

			// URL Shortener
			case 'bitly':
			case 'bt': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://www.tytydmu.com`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/url-shortener/bitly?api_key=' + apiKey + '&target_url=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						text: data.data.url_shortener
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'cuttly':
			case 'ct': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://www.tytydmu.com`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/url-shortener/cuttly?api_key=' + apiKey + '&target_url=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						text: data.data.url_shortener
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'tinyurl':
			case 'tu': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://www.tytydmu.com`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/url-shortener/tinyurl?api_key=' + apiKey + '&target_url=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						text: data.data.url_shortener
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'tinyurlwithalias':
			case 'tua': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query1 || !query2) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://www.tytydmu.com|fannnn`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, apiKey, query1, query2) {
						const data = await fetch(apiUrl + '/api/url-shortener/tinyurl-with-alias?api_key=' + apiKey + '&target_url=' + query1 + '&alias=' + query2);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query1, query2);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						text: data.data.url_shortener
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'tinyurlresolve':
			case 'tr': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://www.tytydmu.com`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);

					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/url-shortener/tinyurl-resolve?api_key=' + apiKey + '&target_url=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					//console.log(data);
					client.sendMessage(jid, {
						text: data.data.original_url
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			// Play
			case 'play': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} [gunakanlink/judul]`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, query, apiKey) {
						const data = await fetch(apiUrl + '/api/play-v2?q=' + query + '&apikey=' + apiKey);
						return data.json();
					};

					const data = await fetchData(config.api.neo.api_url, query, config.api.neo.api_key);
					if (!data) return reply('Not found');
					const {
						title,
						thubmnail,
						duration,
						channel
					} = data;
					const {
						filename,
						quality,
						size,
						extension,
						url
					} = data.data;
					const audio_url = url;
					const response = `${config.pro}`

					console.log(data);
					client.sendImageMessage(jid, `${title}`, `Channel : ${channel} | ${duration}`, config.linkgc, thubmnail, response, true, true, quoted);

					setTimeout(() => {
						client.sendMessage(jid, {
							audio: {
								url: audio_url
							},
							mimetype: 'audio/mpeg',
							ptt: false
						}, {
							quoted: messages
						}).then(() => {
							const reactionMessageCompleted = {
								react: {
									text: config.react.success,
									key: messageKey,
								},
							};
							client.sendMessage(jid, reactionMessageCompleted);

							if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
								user.dailyLimit -= 1;
								user.save();
							};
						}).catch((error) => {
							const errorMessage = `Error: ${error.message}`;
							reply(errorCookk);
							console.error(errorMessage);
						});
					}, 5000);
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			// To Image / Video

			// Tools
			case 'whois':
			case 'wi': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://api.sim-c.xyz`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/tools/whois?api_key=' + apiKey + '&domain=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');
					const response = `
*WhoIs*
Domain Name: ${data.data.domainName}
Registrar: ${data.data.registrar}
Creation Date: ${data.data.creationDate}
Updated Date: ${data.data.updatedDate}
Registrar URL: ${data.data.registrarUrl}
Domain Status: ${data.data.domainStatus}
Registrant Name: ${data.data.registrantName}
Registrant Organization: ${data.data.registrantOrganization}
Registrant Address: ${data.data.registrantStreet}, ${data.registrantCity}, ${data.registrantStateProvince}, ${data.registrantPostalCode}, ${data.registrantCountry}
Registrant Phone: ${data.data.registrantPhone}
Registrant Email: ${data.data.registrarAbuseContactEmail}
Admin Name: ${data.data.adminName}
Admin Organization: ${data.data.adminOrganization}
Admin Address: ${data.data.adminStreet}, ${data.adminCity}, ${data.adminStateProvince}, ${data.adminPostalCode}, ${data.adminCountry}
Admin Phone: ${data.data.adminPhone}
Tech Name: ${data.data.techName}
Tech Organization: ${data.data.techOrganization}
Tech Address: ${data.data.techStreet}, ${data.techCity}, ${data.techStateProvince}, ${data.techPostalCode}, ${data.techCountry}
Tech Phone: ${data.data.techPhone}
Name Servers: ${data.data.nameServer}
DNSSEC: ${data.data.dnssec}
Last Update of Whois Database: ${data.data.lastUpdateOfWhoisDatabase}
Terms of Use: ${data.data.termsOfUse}`;
					reply(response);
					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'translate':
			case 'tl': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query1 || !query2) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} Saya seorang FullStack Web Developer|en`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query1, query2) {
						const data = await fetch(apiUrl + '/api/tools/translate?api_key=' + apiKey + '&text=' + query1 + '&language=' + query2);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query1, query2);
					if (!data) return reply('Not found');
					const response = `*Translate to ${query2}*\n*Original text:* ${data.data.original_text}\n*Translated text:* ${data.data.translated_text}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'tempmail':
			case 'tm': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey) {
						const data = await fetch(apiUrl + '/api/tools/get-tempmail?api_key=' + apiKey);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key);
					if (!data) return reply('Not found');

					const date = new Date(data.data[2]);
					const dateString = date.toISOString();

					const options = {
						year: 'numeric',
						month: 'long',
						day: 'numeric',
						hour: '2-digit',
						minute: '2-digit',
						second: '2-digit',
						timeZoneName: 'short'
					};
					const formattedDate = date.toLocaleString('id-ID', options);

					const response = `*Tempmail*\n*Email address:* ${data.data[0]}\n*Id:* ${data.data[1]}\n*Date:* ${formattedDate}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'tempmailinbox':
			case 'tmi': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} blablabla`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/tools/get-tempmail-inbox?api_key=' + apiKey + '&id=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');

					const inboxData = data.data[0];
					let inboxContent = '';

					for (const message of inboxData) {
						inboxContent += `To: ${message.toAddr}\n`;
						inboxContent += `Text: ${message.text}\n`;
						inboxContent += `Raw Size: ${message.rawSize}\n`;
						inboxContent += `Subject: ${message.headerSubject}\n`;
						inboxContent += `From: ${message.fromAddr}\n`;
						inboxContent += `Download URL: ${message.downloadUrl}\n\n`;
					}

					const response = `*Tempmail Inbox*\n*Id:* ${q}\n*All inbox:*\n${inboxContent}`;

					//console.log(data);
					client.sendMessage(jid, {
						text: response
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'screenshotwebiste':
			case 'ssweb':
			case 'sw': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query1 || !query2) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://api.sim-c.xyz|desktop`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query1, query2) {
						const data = apiUrl + '/api/tools/screenshot-website?api_key=' + apiKey + '&target_url=' + query1 + '&device=' + query2;
						return data;
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query1, query2);
					if (!data) return reply('Not found');

					//console.log(data);
					client.sendMessage(jid, {
						image: {
							url: data
						},
						caption: `*URL:* ${query1} *Device:* ${query2}`,
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'fetch':
			case 'get': {
				const username = query;
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});

				if (!user || (user.accountType === 'Free' && user.dailyLimit <= 0)) {
					if (!user) {
						const reactionMessageNoRegist = {
							react: {
								text: config.react.noregist,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageNoRegist);
						reply(config.message.not_registered);
					} else {
						const reactionMessageLimit = {
							react: {
								text: config.react.limit,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageLimit);
						reply(config.message.daily_limit);
					}
					return;
				};

				if (!query) {
					return reply(`*contoh:* ${config.prefix}${cleanCommand} https://example.com`);
				};

				try {
					const reactionMessage = {
						react: {
							text: config.react.process,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessage);
					async function fetchData(apiUrl, apiKey, query) {
						const data = await fetch(apiUrl + '/api/tools/fetch?api_key=' + apiKey + '&target_url=' + query);
						return data.json();
					};

					const data = await fetchData(config.api.fannn.api_url, config.api.fannn.api_key, query);
					if (!data) return reply('Not found');

					//console.log(data);
					client.sendMessage(jid, {
						text: data.data
					}, {
						quoted: messages
					}).then(() => {
						const reactionMessageCompleted = {
							react: {
								text: config.react.success,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageCompleted);

						if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
							user.dailyLimit -= 1;
							user.save();
						};
					}).catch((error) => {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					});
				} catch (error) {
					const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
					const reactionMessageError = {
						react: {
							text: config.react.failed,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageError);
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			// Owner area
			case 'showdata':
			case 'showalldata':
			case 'showusers':
			case 'viewusers': {
				if (isOwner) {
					try {
						const allUsers = await User.find({});
						if (allUsers.length > 0) {
							let userList = `\`Users registered in the database\`\n\n`;
							allUsers.forEach((user, index) => {
								let dailyLimit = user.accountType === 'Premium' ? 'Infinity' : user.dailyLimit;
								const phoneNumberDigitsOnly = user.phoneNumber.replace(/\D/g, '');

								userList += `\`${index + 1})\`\n> *Username:* _${user.username}_\n> *Phone Number:* _${phoneNumberDigitsOnly}_\n> *Account Type:* _${user.accountType}_\n> *Daily Limit:* _${dailyLimit}_\n> *Expiration Date:* _${user.expirationDate ? user.expirationDate.toISOString().split('T')[0] : 'No Expiration Date'}_\n\n`;
							});
							reply(userList);
						} else {
							reply("Tidak ada pengguna yang ditemukan.");
						}
					} catch (error) {
						console.error(error);
						reply("Terjadi kesalahan saat mengambil data pengguna.");
					}
				} else {
					reply("Anda tidak memiliki izin untuk menggunakan perintah ini.");
				}
				break;
			}

			case 'makeprem':
			case 'makepremium':
			case 'addprem':
			case 'addpremium': {
				if (isOwner) {
					const [username, duration] = q.split('|').map(item => item.trim());

					if (!username || !duration) {
						reply('Mohon berikan username dan durasi yang sesuai.');
						return;
					}

					const existingUser = await User.findOne({
						username: username
					});
					if (!existingUser) {
						reply(`Username ${username} belum terdaftar di database.`);
						return;
					}

					let expirationDate = new Date(); // Inisialisasi expirationDate dengan objek Date saat ini

					if (duration.includes('second')) {
						const seconds = parseInt(duration);
						expirationDate.setSeconds(expirationDate.getSeconds() + seconds);
					} else if (duration.includes('minute')) {
						const minutes = parseInt(duration);
						expirationDate.setMinutes(expirationDate.getMinutes() + minutes);
					} else if (duration.includes('hour')) {
						const hours = parseInt(duration);
						expirationDate.setHours(expirationDate.getHours() + hours);
					} else if (duration.includes('day')) {
						const days = parseInt(duration);
						expirationDate.setDate(expirationDate.getDate() + days);
					} else if (duration.includes('week')) {
						const weeks = parseInt(duration);
						expirationDate.setDate(expirationDate.getDate() + weeks * 7);
					} else if (duration.includes('month')) {
						const months = parseInt(duration);
						expirationDate.setMonth(expirationDate.getMonth() + months);
					} else if (duration.includes('year')) {
						const years = parseInt(duration);
						const maxYears = 1;
						const limitedYears = Math.min(years, maxYears);
						expirationDate.setFullYear(expirationDate.getFullYear() + limitedYears);

						if (years > maxYears) {
							reply('Durasi maksimal adalah 1 tahun. Akun telah diatur untuk 1 tahun.');
						}
					} else {
						reply('Durasi tidak valid. Gunakan satuan waktu seperti second, minute, hour, day, week, month, atau year.');
						return;
					}

					await User.findOneAndUpdate({
						username: username
					}, {
						accountType: 'Premium',
						dailyLimit: -1,
						expirationDate: expirationDate
					});

					const expirationDateFormatted = expirationDate.toLocaleString('id-ID', {
						day: '2-digit',
						month: '2-digit',
						year: 'numeric',
						hour: '2-digit',
						minute: '2-digit',
						second: '2-digit'
					});

					reply(`Akun dengan username ${username} telah diubah menjadi Premium dengan limit yang tidak terbatas. Tanggal kedaluwarsa: ${expirationDateFormatted}`);
				} else {
					const reactionMessageOwner = {
						react: {
							text: config.react.noowner,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageOwner);
					reply(config.message.especially_owners);
				}
				break;
			};

			case 'deleteprem':
			case 'dellprem': {
				if (isOwner) {
					const username = query;

					if (!username) {
						reply('Mohon berikan username yang sesuai.');
						return;
					};

					try {
						const user = await User.findOneAndUpdate({
							username: username,
							accountType: 'Premium'
						}, {
							$set: {
								accountType: 'Free',
								dailyLimit: config.daily_limit.free,
								expirationDate: null
							}
						});

						if (user) {
							reply(`Akun dengan username ${username} telah diubah menjadi Free dengan limit harian ${config.daily_limit.free}. Tanggal kadaluarsa: -`);
						} else {
							reply(`Tidak dapat menemukan akun dengan username ${username} atau akun ini bukan tipe Premium.`);
						};
					} catch (error) {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					};
				} else {
					const reactionMessageOwner = {
						react: {
							text: config.react.noowner,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageOwner);
					reply(config.message.especially_owners);
				}
				break;
			};

			case 'deleteuser': {
				if (isOwner) {
					const username = query;
					if (!username) {
						reply('Mohon berikan username yang sesuai.');
						return;
					};
					try {
						const deletedUser = await User.findOneAndDelete({
							username: username
						});
						if (deletedUser) {
							reply(`Akun dengan username ${username} telah dihapus.`);
						} else {
							reply(`Tidak dapat menemukan akun dengan username ${username}.`);
						};
					} catch (error) {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					};
				} else {
					const reactionMessageOwner = {
						react: {
							text: config.react.noowner,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageOwner);
					reply(config.message.especially_owners);
				}
				break;
			};

			case 'deleteallusers': {
				if (isOwner) {
					try {
						const deleteResult = await User.deleteMany({});
						if (deleteResult.deletedCount > 0) {
							reply(`Semua pengguna telah dihapus (${deleteResult.deletedCount} pengguna).`);
						} else {
							reply('Tidak ada pengguna untuk dihapus.');
						};
					} catch (error) {
						const errorMessage = `Error: ${error.message}`;
						reply(errorCookk);
						console.error(errorMessage);
					};
				} else {
					const reactionMessageOwner = {
						react: {
							text: config.react.noowner,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageOwner);
					reply(config.message.especially_owners);
				}
				break;
			};

			case 'deletemessage':
			case 'dell':
			case 'delete':
			case 'd': {
				if (isOwner) {
					try {
						client.sendMessage(jid, {
							delete: {
								remoteJid: jid,
								fromMe: true,
								id: messages.quoted.id,
								participant: messages.quoted.sender
							}
						})
					} catch (error) {
						reply('Silahkan reply pesan dari bot terlebih dahulu!');
						//console.error(error);
					};
				} else {
					const reactionMessageOwner = {
						react: {
							text: config.react.noowner,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageOwner);
					reply(config.message.especially_owners);
				}
				break;
			};

			case 'creategroup': {
				if (isOwner) {
					const groupName = `${randomGroupname.value} ✅`;;
					const participants = [`${config.owner.number}@s.whatsapp.net`];

					if (!query || query.trim() === '') {} else {
						participants.push(`${query}@s.whatsapp.net`);
					}

					try {
						const response = await client.groupCreate(groupName, participants);
						console.log('Grup berhasil dibuat:', response);
						let replyMessage = `Grup "${groupName}" berhasil dibuat`;
						if (query && query.trim() !== '') {
							replyMessage += `, dan nomor ${query} ditambahkan ke dalam grup.`;
						}
						reply(replyMessage);
					} catch (error) {
						console.error('Gagal membuat grup:', error);
						reply('Gagal membuat grup. Silakan coba lagi.');
					}
				} else {
					const reactionMessageOwner = {
						react: {
							text: config.react.noowner,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageOwner);
					reply(config.message.especially_owners);
				}
				break;
			};

			// Auth area
			case 'register': {
				const rawUsername = query;
				const phoneNumber = senderNumber;

				const username = rawUsername.replace(/\s+/g, '').toLowerCase();

				const existingUser = await User.findOne({
					$or: [{
						username: username
					}, {
						phoneNumber: phoneNumber
					}]
				});
				if (existingUser) {
					reply(`Username atau nomor telepon sudah terdaftar. Silahkan gunakan username lain.`);
					return;
				};

				if (!username) {
					reply(`Mohon berikan username yang sesuai. Contoh: ${config.prefix}${cleanCommand} fannn`);
					return;
				};
				if (rawUsername !== username) {
					reply('Username hanya boleh mengandung huruf kecil dan tidak boleh ada spasi.');
					return;
				}

				const minUsernameLength = 3;
				const maxUsernameLength = 15;

				if (username.length < minUsernameLength || username.length > maxUsernameLength) {
					reply(`Panjang username harus antara ${minUsernameLength} dan ${maxUsernameLength} karakter.`);
					return;
				}

				const newUser = new User({
					username: username,
					accountType: 'Free',
					dailyLimit: config.daily_limit.free,
					phoneNumber: phoneNumber
				});

				try {
					await newUser.save();
					const phoneNumberDigitsOnly = phoneNumber.replace(/\D/g, '');
					reply(`\`Registration Successful ✅\`
> *Username:* ${username}
> *Phone Number:* @${phoneNumberDigitsOnly}
> *Daily limit:* ${config.daily_limit.free}`);
				} catch (error) {
					const errorMessage = `Error: ${error.message}`;
					reply(errorCookk);
					console.error(errorMessage);
				};
				break;
			};

			case 'myinfo':
			case 'myinformation':
			case 'accountinformation':
			case 'accountinfo': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					reply(`Anda belum terdaftar sebagai pengguna.`);
					return;
				};

				let dailyLimit = user.accountType === 'Premium' ? 'Infinity' : user.dailyLimit;
				let expirationDateFormatted = user.accountType === 'Premium' ? user.expirationDate.toLocaleString('id-ID', {
					day: '2-digit',
					month: '2-digit',
					year: 'numeric',
					hour: '2-digit',
					minute: '2-digit',
					second: '2-digit'
				}) : '-';
				reply(`\`Informasi Akun:\`
> *Username:* ${user.username}
> *Account Type:* ${user.accountType}
> *Daily Limit:* ${dailyLimit}
> *Expired Date:* ${expirationDateFormatted}`);
				break;
			};

			case 'checklimit':
			case 'checkusagelimit': {
				const phoneNumber = senderNumber;

				const user = await User.findOne({
					phoneNumber: phoneNumber
				});

				if (!user) {
					const reactionMessageNoRegist = {
						react: {
							text: config.react.noregist,
							key: messageKey,
						},
					};
					client.sendMessage(jid, reactionMessageNoRegist);
					reply(config.message.not_registered);
					return;
				};

				if (user.accountType === 'Free') {
					reply(`\`Limit harian Anda: ${user.dailyLimit}\``);
				} else if (user.accountType === 'Premium') {
					reply(`Anda adalah pengguna Premium dengan limit tak terbatas.`);
				};
				break;
			};

			// BATAS PENAMBAHAN FITUR

			/*
			
╔┈┈┈┈「 *Your Information* 」
╎╭─────────✧
╎│❏ *Username:* ${user.username}
╎│❏ *Phone Number:* @${phoneNumberDigitsOnly}
╎│❏ *Account Type:* ${user.accountType}
╎│❏ *Daily Limit:* ${dailyLimit}
╎╰─────────────✧
╠┈┈┈┈「 *Main Menu* 」
╎╭──────────✧
╎│㊂ *${config.prefix}allmenu*
╎│㊂ *${config.prefix}ai*
╎│㊂ *${config.prefix}downloader*
╎│㊂ *${config.prefix}searcher*
╎│㊂ *${config.prefix}stalker*
╎│㊂ *${config.prefix}maker*
╎│㊂ *${config.prefix}urlshortener*
╎│㊂ *${config.prefix}converter*
╎│㊂ *${config.prefix}islamic*
╎│㊂ *${config.prefix}tools*
╎│㊂ *${config.prefix}auth*
╎│㊂ *${config.prefix}owner*
╎╰────────────✧
╚┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
			*/
			// Haram / Bokep
			case 'xnxx': {
				if (isInsider) {
					const username = query;
					const phoneNumber = senderNumber;

					const user = await User.findOne({
						$or: [{
							username: username
						}, {
							phoneNumber: phoneNumber
						}]
					});
					if (!query) {
						return reply(`*contoh:* ${config.prefix}${cleanCommand} https://www.xnxx.com/video-trjih46/sexo_em_free_fire_com_varias_mulheres_rebolando_para_dotado`);
					};

					try {
						const reactionMessage = {
							react: {
								text: config.react.process,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessage);
						async function fetchData(apiUrl, query) {
							const data = await fetch(apiUrl + '/tools/xnxxdl?url=' + query);
							return data.json();
						};

						const data = await fetchData(config.api.beta.api_url, query);
						if (!data) return reply('Not found');
						const {
							keyword,
							duration,
							quality,
							views,
							thumb,
							url
						} = data.result;
						const video_url = url;

						//console.log(data);
						const userJid = user.phoneNumber + '@s.whatsapp.net';

						const generateFN = getRmasIcan() + generateFilename(6);

						client.sendMessage(userJid, {
							document: {
								url: video_url
							},
							fileName: generateFN + '.mp4',
							caption: `${config.caption}`,
							mimetype: 'video/mp4'
						}, {
							quoted: messages
						}).then(() => {
							const reactionMessageCompleted = {
								react: {
									text: '😁',
									key: messageKey,
								},
							};
							client.sendMessage(jid, reactionMessageCompleted);

							if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
								user.dailyLimit -= 1;
								user.save();
							};
						}).catch((error) => {
							const errorMessage = `Error: ${error.message}`;
							console.error(errorMessage);
						});
					} catch (error) {
						const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
						const reactionMessageError = {
							react: {
								text: config.react.failed,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageError);
						reply(errorCookk);
						console.error(errorMessage);
					};
				} else {
					/* MBOH */
				}
				break;
			};

			case 'xvideos': {
				if (isInsider) {
					const username = query;
					const phoneNumber = senderNumber;

					const user = await User.findOne({
						$or: [{
							username: username
						}, {
							phoneNumber: phoneNumber
						}]
					});
					if (!query) {
						return reply(`*contoh:* ${config.prefix}${cleanCommand} https://www.xvideos.com/video67912481/innocent_elf_emilia_from_re_zero_was_passionately_fucked_in_tight_pussy_and_mouth_by_her_real_life_fan`);
					};

					try {
						const reactionMessage = {
							react: {
								text: config.react.process,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessage);
						async function fetchData(apiUrl, query) {
							const data = await fetch(apiUrl + '/tools/xvideosdl?url=' + query);
							return data.json();
						};

						const data = await fetchData(config.api.beta.api_url, query);
						if (!data) return reply('Not found');
						const {
							url
						} = data.result;
						const video_url = url;

						//console.log(data);
						const userJid = user.phoneNumber + '@s.whatsapp.net';

						const generateFN = getRmasIcan() + generateFilename(6);

						client.sendMessage(userJid, {
							document: {
								url: video_url
							},
							fileName: generateFN + '.mp4',
							caption: `${config.caption}`,
							mimetype: 'video/mp4'
						}, {
							quoted: messages
						}).then(() => {
							const reactionMessageCompleted = {
								react: {
									text: '😁',
									key: messageKey,
								},
							};
							client.sendMessage(jid, reactionMessageCompleted);

							if (user && user.accountType === 'Free' && user.dailyLimit > 0) {
								user.dailyLimit -= 1;
								user.save();
							};
						}).catch((error) => {
							const errorMessage = `Error: ${error.message}`;
							console.error(errorMessage);
						});
					} catch (error) {
						const errorMessage = `API key tidak valid / Limit API key telah habis / Error: ${error.message}`;
						const reactionMessageError = {
							react: {
								text: config.react.failed,
								key: messageKey,
							},
						};
						client.sendMessage(jid, reactionMessageError);
						reply(errorCookk);
						console.error(errorMessage);
					};
				} else {
					/* MBOH */
				}
				break;
			};

			default: {
				const {
					closestMatch,
					similarityPercentage
				} = suggestCommand(cleanCommand, cleanCommands);
				let infoMessage;
				if (closestMatch) {
					infoMessage = `Fitur *${command}* tidak tersedia. Mungkin Fitur *${closestMatch}* yang Anda maksud?\n\n> Fitur *${closestMatch}* Memiliki Tingkat Kemiripan: ${similarityPercentage.toFixed(2)}%`;
				} else {
					infoMessage = `Fitur '${command}' tidak tersedia dan tidak ada saran perintah yang mirip.`;
				};
				const reactionMessageSimilarity = {
					react: {
						text: config.react.similarity,
						key: messageKey,
					},
				};
				client.sendMessage(jid, reactionMessageSimilarity);
				reply(infoMessage);
				console.info(infoMessage);
			};
		};
	} catch (error) {
		reply(`Error: ${error.message}`);
		console.error(error);
	};
};

module.exports = mainFunction;