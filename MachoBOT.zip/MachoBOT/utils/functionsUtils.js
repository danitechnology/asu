/*
 * Source: My Personal Script
 * Information
 * Modified By: Muh*** Irf** M*r** (Fannn.)
 * Contact Modified: 0853 3660 3330 (WhatsApp)
 * DICK CUTTING BEWARE
 */

const {
	proto,
	getContentType
} = require('@whiskeysockets/baileys');
const fs = require('fs');
const {
	tmpdir
} = require('os');
const crypto = require('crypto');
const ff = require('fluent-ffmpeg');
const webp = require('node-webpmux');
const path = require('path');
const axios = require('axios');
const difflib = require('difflib');
const BodyForm = require('form-data');
const mime = require('mime-types');
const moment = require('moment-timezone');
const {
	fromBuffer
} = require('file-type');
const MAX_FILE_SIZE_MB = 300; // Batas 1,5 GB untuk pengguna gratis (1,5 GB × 1024 MB = 1536)

function smsg(conn, m, store) {
	if (!m) return m;
	let M = proto.WebMessageInfo;
	if (m.key) {
		m.id = m.key.id;
		m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16;
		m.chat = m.key.remoteJid;
		m.fromMe = m.key.fromMe;
		m.isGroup = m.chat.endsWith('@g.us');
		m.sender = conn.decodeJid(m.fromMe && conn.user.id || m.participant || m.key.participant || m.chat || '');
		if (m.isGroup) m.participant = conn.decodeJid(m.key.participant) || '';
	}
	if (m.message) {
		m.mtype = getContentType(m.message);
		m.msg = (m.mtype == 'viewOnceMessage' ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : m.message[m.mtype]);
		m.body = m.message.conversation || m.msg.caption || m.msg.text || (m.mtype == 'listResponseMessage') && m.msg.singleSelectReply.selectedRowId || (m.mtype == 'buttonsResponseMessage') && m.msg.selectedButtonId || (m.mtype == 'viewOnceMessage') && m.msg.caption || m.text;
		let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null;
		m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
		if (m.quoted) {
			let type = Object.keys(m.quoted)[0];
			m.quoted = m.quoted[type];
			if (['productMessage'].includes(type)) {
				type = Object.keys(m.quoted)[0];
				m.quoted = m.quoted[type];
			}
			if (typeof m.quoted === 'string') m.quoted = {
				text: m.quoted
			};
			m.quoted.mtype = type;
			m.quoted.id = m.msg.contextInfo.stanzaId;
			m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat;
			m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false;
			m.quoted.sender = conn.decodeJid(m.msg.contextInfo.participant);
			m.quoted.fromMe = m.quoted.sender === conn.decodeJid(conn.user.id);
			m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || '';
			m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
			m.getQuotedObj = m.getQuotedMessage = async () => {
				if (!m.quoted.id) return false;
				let q = await store.loadMessage(m.chat, m.quoted.id, conn);
				return exports.smsg(conn, q, store);
			};
			let vM = m.quoted.fakeObj = M.fromObject({
				key: {
					remoteJid: m.quoted.chat,
					fromMe: m.quoted.fromMe,
					id: m.quoted.id
				},
				message: quoted,
				...(m.isGroup ? {
					participant: m.quoted.sender
				} : {})
			});
			m.quoted.delete = () => conn.sendMessage(m.quoted.chat, {
				delete: vM.key
			});
			m.quoted.copyNForward = (jid, forceForward = false, options = {}) => conn.copyNForward(jid, vM, forceForward, options);
			m.quoted.download = () => conn.downloadMediaMessage(m.quoted);
		}
	}
	if (m.msg.url) m.download = () => conn.downloadMediaMessage(m.msg);
	m.text = m.msg.text || m.msg.caption || m.message.conversation || m.msg.contentText || m.msg.selectedDisplayText || m.msg.title || '';
	m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? conn.sendMedia(chatId, text, 'file', '', m, {
		...options
	}) : conn.sendText(chatId, text, m, {
		...options
	});
	m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)));
	m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => conn.copyNForward(jid, m, forceForward, options);
	conn.appenTextMessage = async (text, chatUpdate) => {
		let messages = await generateWAMessage(m.chat, {
			text: text,
			mentions: m.mentionedJid
		}, {
			userJid: conn.user.id,
			quoted: m.quoted && m.quoted.fakeObj
		});
		messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id);
		messages.key.id = m.key.id;
		messages.pushName = m.pushName;
		if (m.isGroup) messages.participant = m.sender;
		let msg = {
			...chatUpdate,
			messages: [proto.WebMessageInfo.fromObject(messages)],
			type: 'append'
		};
		conn.ev.emit('messages.upsert', msg);
	};
	return m;
};

async function fetchJson(url, options) {
	options = options ? options : {};
	const response = await fetch(url, {
		method: 'GET',
		headers: {
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
		},
		...options,
	});
	const data = await response.json();
	return data;
};

async function fetchBuffer(url, options) {
	options = options ? options : {};
	const response = await fetch(url, {
		method: 'GET',
		headers: {
			'DNT': '1',
			'Upgrade-Insecure-Request': '1'
		},
		...options,
	});
	const data = await response.arrayBuffer();
	return data;
};

async function writeExifImage(media, metadata) {
	let wMedia = await imageToWebp(media);
	const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
	const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
	fs.writeFileSync(tmpFileIn, wMedia);
	if (metadata.packname || metadata.author) {
		const img = new webp.Image();
		const json = {
			"sticker-pack-name": metadata.packname,
			"sticker-pack-publisher": metadata.author,
			"emojis": metadata.categories ? metadata.categories : [""]
		};
		const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
		const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
		const exif = Buffer.concat([exifAttr, jsonBuff]);
		exif.writeUIntLE(jsonBuff.length, 14, 4);
		await img.load(tmpFileIn);
		fs.unlinkSync(tmpFileIn);
		img.exif = exif;
		await img.save(tmpFileOut);
		return tmpFileOut;
	};
};

async function writeExifVideo(media, metadata) {
	let wMedia = await videoToWebp(media);
	const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
	const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
	fs.writeFileSync(tmpFileIn, wMedia);
	if (metadata.packname || metadata.author) {
		const img = new webp.Image();
		const json = {
			"sticker-pack-name": metadata.packname,
			"sticker-pack-publisher": metadata.author,
			"emojis": metadata.categories ? metadata.categories : [""]
		};
		const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
		const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
		const exif = Buffer.concat([exifAttr, jsonBuff]);
		exif.writeUIntLE(jsonBuff.length, 14, 4);
		await img.load(tmpFileIn);
		fs.unlinkSync(tmpFileIn);
		img.exif = exif;
		await img.save(tmpFileOut);
		return tmpFileOut;
	};
};

async function imageToWebp(media) {
	const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
	const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.jpg`);

	fs.writeFileSync(tmpFileIn, media);

	await new Promise((resolve, reject) => {
		ff(tmpFileIn)
			.on("error", reject)
			.on("end", () => resolve(true))
			.addOutputOptions([
				"-vcodec",
				"libwebp",
				"-vf",
				"scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
			])
			.toFormat("webp")
			.save(tmpFileOut)
	});

	const buff = fs.readFileSync(tmpFileOut);
	fs.unlinkSync(tmpFileOut);
	fs.unlinkSync(tmpFileIn);
	return buff;
};

async function videoToWebp(media) {
	const tmpFileOut = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
	const tmpFileIn = path.join(tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp4`);

	fs.writeFileSync(tmpFileIn, media);

	await new Promise((resolve, reject) => {
		ff(tmpFileIn)
			.on("error", reject)
			.on("end", () => resolve(true))
			.addOutputOptions([
				"-vcodec",
				"libwebp",
				"-vf",
				"scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
				"-loop",
				"0",
				"-ss",
				"00:00:00",
				"-t",
				"00:00:05",
				"-preset",
				"default",
				"-an",
				"-vsync",
				"0"
			])
			.toFormat("webp")
			.save(tmpFileOut)
	});

	const buff = fs.readFileSync(tmpFileOut);
	fs.unlinkSync(tmpFileOut);
	fs.unlinkSync(tmpFileIn);
	return buff;
};

function suggestCommand(userInput, cleanCommands) {
	const matches = difflib.getCloseMatches(userInput, cleanCommands, 1, 0.0);
	if (matches.length > 0) {
		const closestMatch = matches[0];
		const similarity = new difflib.SequenceMatcher(null, userInput, closestMatch).ratio();
		const similarityPercentage = similarity * 100;
		return {
			closestMatch,
			similarityPercentage
		};
	}
	return {
		closestMatch: null,
		similarityPercentage: 0
	};
};

function imageUploader(Path) {
	return new Promise(async (resolve, reject) => {
		if (!fs.existsSync(Path)) return reject(new Error("File not Found"));
		try {
			const form = new BodyForm();
			form.append("file", fs.createReadStream(Path));
			const data = await axios({
				url: "https://telegra.ph/upload",
				method: "POST",
				headers: {
					...form.getHeaders()
				},
				data: form
			});
			return resolve("https://telegra.ph" + data.data[0].src);
		} catch (err) {
			return reject(new Error(String(err)));
		};
	});
};

function getCurrentGreeting() {
	const currentHour = new Date().getHours();
	if (currentHour < 12) {
		return 'Selamat Pagi 🌅';
	} else if (currentHour < 15) {
		return 'Selamat Siang ☀️';
	} else if (currentHour < 18) {
		return 'Selamat Sore 🌄';
	} else {
		return 'Selamat Malam 🌃';
	}
};

function getRmasIcan() {
	const masIcan = [
		"MachoBOT🥶",
		"Fannn😇",
		"Done✅",
		"IC4N🗿"
	];
	return masIcan[Math.floor(Math.random() * masIcan.length)];
};

function generateFilename(length = 6) {
	const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	let filename = '';
	for (let i = 0; i < length; i++) {
		const randomIndex = Math.floor(Math.random() * characters.length);
		filename += characters[randomIndex];
	}
	return filename;
};

function getMimeType(filePath) {
	return mime.lookup(filePath);
};

function getFileExtension(type) {
	switch (type) {
		case 'audio/mpeg':
			return 'mp3';
	return mime.extension(type);
	}
};

const randomGroupname = {
	get value() {
		const length = 5;
		const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		let groupname = "";

		for (let i = 0; i < length; i++) {
			const randomIndex = Math.floor(Math.random() * charset.length);
			groupname += charset[randomIndex];
		}

		return groupname;
	}
};

function isPremiumUser(user) {
	return user && user.accountType === 'Premium';
};

function checkFileSize(fileSizeMB, user) {
	if (isPremiumUser(user)) {
		return true;
	}
	return fileSizeMB <= MAX_FILE_SIZE_MB;
};

function getRandomQuality() {
	const quality = [
		"480p",
		"720p",
		"1080p"
	];
	return quality[Math.floor(Math.random() * quality.length)];
};

function getRandomMerror() {
	const errorCok = [
		"Terjadi kesalahan saat pemrosesan data",
		"Server Error (Data tidak ditemukan)",
		"Server Sedang NGOPI",
		"Gagal memproses Data"
	];
	return errorCok[Math.floor(Math.random() * errorCok.length)];
};

function formatViews(views) {
    if (views >= 1000) {
        return (views / 1000).toFixed(1) + 'k';
    } else {
        return views.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
};

function formatDuration(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;

    return [
        h > 0 ? h.toString().padStart(2, '0') : null,
        m.toString().padStart(2, '0'),
        s.toString().padStart(2, '0')
    ].filter(Boolean).join(":");
};

function formatSize(bytes) {
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return '0 B';
    const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
    return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
};

function formatDate(dateString) {
    const date = moment(dateString);
    const now = moment();
    if (date.isAfter(now)) {
        return "in the future";
    };
    
    const timeAgo = date.fromNow();

    return timeAgo;
};

module.exports = {
	smsg,
	fetchJson,
	fetchBuffer,
	writeExifImage,
	writeExifVideo,
	imageToWebp,
	videoToWebp,
	suggestCommand,
	imageUploader,
	getCurrentGreeting,
	getRmasIcan,
	generateFilename,
	getMimeType,
	getFileExtension,
	randomGroupname,
	isPremiumUser,
	checkFileSize,
	getRandomQuality,
	getRandomMerror,
	formatViews,
	formatDuration,
	formatSize,
	formatDate
};