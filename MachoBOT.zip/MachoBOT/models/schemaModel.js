/*
 * Source: My Personal Script
 * Information
 * Modified By: Muh*** Irf** M*r** (Fannn.)
 * Contact Modified: 0853 3660 3330 (WhatsApp)
 * DICK CUTTING BEWARE
*/

const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: String,
  phoneNumber: String,
  accountType: String,
  dailyLimit: Number,
  isPremium: Boolean,
  expirationDate: Date
});

module.exports = mongoose.model('User', userSchema);