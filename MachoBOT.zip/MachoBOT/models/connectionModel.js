/*
 * Source: My Personal Script
 * Information
 * Modified By: Muh*** Irf** M*r** (Fannn.)
 * Contact Modified: 0853 3660 3330 (WhatsApp)
 * DICK CUTTING BEWARE
*/

const mongoose = require('mongoose');
const chalk = require('chalk');

const config = require('../config/mainConfig.js');

let db = mongoose.connection;

mongoose.connect(config.mongodb_uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

module.exports = db;